import tensorflow as tf
import numpy as np
import scipy.io as sio
import time
from pyDOE import lhs
from Compute_Jacobian import jacobian
import matplotlib.pyplot as plt

np.random.seed(1234)
tf.set_random_seed(1234)

class Sampler:
    def __init__(self, dim, coords, func, name=None):
        self.dim = dim
        self.coords = coords
        self.func = func
        self.name = name

    def sample(self, N):
        x = self.coords[0:1, :] + (self.coords[1:2, :] - self.coords[0:1, :]) * np.random.rand(N, self.dim)
        y = self.func(x)
        return x, y
class DataSampler:
    # Initialize the class for direct data sampling
    def __init__(self, X, Y, name=None):
        self.X = X
        self.Y = Y
        self.name = name
        self.dim = X.shape[1]
        self.total_points = X.shape[0]

    def sample(self, N):
        if N > self.total_points:
            idx = np.random.choice(self.total_points, N, replace=True)
        else:
            idx = np.random.choice(self.total_points, N, replace=False)
        X_batch = self.X[idx, :]
        Y_batch = self.Y[idx, :]
        return X_batch, Y_batch

class LHSSampler:
    def __init__(self, dim, coords, name=None):
        self.dim = dim
        self.coords = coords
        self.name = name

    def sample(self, N):
        samples = lhs(self.dim, N)
        x = self.coords[0:1, :] + (self.coords[1:2, :] - self.coords[0:1, :]) * samples
        return x, np.zeros((x.shape[0], 2))

class FHN_PINN_mFF_NTK:
    def __init__(self, data_sampler, res_sampler, bc_sampler,
                 ic_sampler,
                 layers, nu1, nu2, kernel_size):
        X, _ = res_sampler.sample(np.int32(1e3))
        self.mu_X, self.sigma_X = X.mean(0), X.std(0)
        self.mu_t, self.sigma_t = self.mu_X[0], self.sigma_X[0]
        self.mu_x, self.sigma_x = self.mu_X[1], self.sigma_X[1]

        # Samplers
        self.data_sampler = data_sampler
        self.res_sampler = res_sampler
        self.bc_sampler = bc_sampler
        self.ic_sampler = ic_sampler

        # net
        self.layers = layers
        self.weights, self.biases = self.initialize_NN(layers)

        w_t_phys_list = [0.099800, 0.049900, 0.149700, 0.000000, 0.199600, 0.249500]
        k_x_phys_list = [0.990000, 0.000000, 1.980000]

        num_t_freqs = len(w_t_phys_list)
        t_dims_per_freq = layers[0] // (num_t_freqs * 2)

        W_t_init_parts = []
        for f_t in w_t_phys_list:
            w_t_scaled = (2.0 * np.pi * f_t) * self.sigma_t
            init_matrix = w_t_scaled * (1.0 + 0.01 * np.random.randn(1, t_dims_per_freq))
            W_t_init_parts.append(init_matrix)

        W_t_init_full = np.concatenate(W_t_init_parts, axis=1).astype(np.float32)

        self.W_t = tf.Variable(W_t_init_full, dtype=tf.float32, trainable=True, name="W_t_trainable")

        num_x_freqs = len(k_x_phys_list)
        x_dims_per_freq = layers[0] // (num_x_freqs * 2)
        W_x_init_parts = []
        for f_x in k_x_phys_list:
            k_x_scaled = (2.0 * np.pi * f_x) * self.sigma_x
            init_matrix = k_x_scaled * (1.0 + 0.01 * np.random.randn(1, x_dims_per_freq))
            W_x_init_parts.append(init_matrix)
        W_x_init_full = np.concatenate(W_x_init_parts, axis=1).astype(np.float32)
        self.W_x = tf.Variable(W_x_init_full, dtype=tf.float32, trainable=True, name="W_x_trainable")

        self.nu1 = tf.constant(nu1, dtype=tf.float32)
        self.nu2 = tf.constant(nu2, dtype=tf.float32)

        self.lambda1 = tf.Variable([0.0], dtype=tf.float32, name='lambda1')
        self.lambda2 = tf.Variable([0.0], dtype=tf.float32, name='lambda2')
        self.lambda3 = tf.Variable([0.0], dtype=tf.float32, name='lambda3')

        self.kernel_size = kernel_size
        self.D_data = 2 * self.kernel_size
        self.D_res = 2 * self.kernel_size
        self.D_bc = 2 * self.kernel_size
        self.D_ic = 2 * self.kernel_size

        self.sess = tf.Session(config=tf.ConfigProto(log_device_placement=False))

        self.u_tf = tf.placeholder(tf.float32, shape=(None, 1))
        self.v_tf = tf.placeholder(tf.float32, shape=(None, 1))
        self.t_data_tf = tf.placeholder(tf.float32, shape=(None, 1))
        self.x_data_tf = tf.placeholder(tf.float32, shape=(None, 1))

        self.u_ic_tf = tf.placeholder(tf.float32, shape=(None, 1))
        self.v_ic_tf = tf.placeholder(tf.float32, shape=(None, 1))
        self.t_ic_tf = tf.placeholder(tf.float32, shape=(None, 1))
        self.x_ic_tf = tf.placeholder(tf.float32, shape=(None, 1))

        self.t_bc_tf = tf.placeholder(tf.float32, shape=(None, 1))
        self.x_bc_tf = tf.placeholder(tf.float32, shape=(None, 1))

        self.t_r_tf = tf.placeholder(tf.float32, shape=(None, 1))
        self.x_r_tf = tf.placeholder(tf.float32, shape=(None, 1))

        self.u_data_pred, self.v_data_pred = self.net_uv(self.t_data_tf, self.x_data_tf)
        self.u_ic_pred, self.v_ic_pred = self.net_uv(self.t_ic_tf, self.x_ic_tf)
        self.u_bc_pred, self.v_bc_pred = self.net_uv_x(self.t_bc_tf, self.x_bc_tf)
        self.r_u_pred, self.r_v_pred = self.net_r(self.t_r_tf, self.x_r_tf)

        self.loss_u_data = tf.reduce_mean(tf.square(self.u_tf - self.u_data_pred))
        self.loss_v_data = tf.reduce_mean(tf.square(self.v_tf - self.v_data_pred))
        self.loss_data = self.loss_u_data + self.loss_v_data

        self.loss_u_ic = tf.reduce_mean(tf.square(self.u_ic_tf - self.u_ic_pred))
        self.loss_v_ic = tf.reduce_mean(tf.square(self.v_ic_tf - self.v_ic_pred))
        self.loss_ic = self.loss_u_ic + self.loss_v_ic

        self.loss_res_u = tf.reduce_mean(tf.square(self.r_u_pred))
        self.loss_res_v = tf.reduce_mean(tf.square(self.r_v_pred))
        self.loss_res = self.loss_res_u + self.loss_res_v

        self.loss_bc_u = tf.reduce_mean(tf.square(self.u_bc_pred))
        self.loss_bc_v = tf.reduce_mean(tf.square(self.v_bc_pred))
        self.loss_bc = self.loss_bc_u + self.loss_bc_v

        self.lambda_data_val = np.array(1.0)
        self.lambda_res_val = np.array(1.0)
        self.lambda_bc_val = np.array(1.0)
        self.lambda_ic_val = np.array(1.0)

        self.lambda_data_tf = tf.placeholder(tf.float32, shape=self.lambda_data_val.shape)
        self.lambda_res_tf = tf.placeholder(tf.float32, shape=self.lambda_res_val.shape)
        self.lambda_bc_tf = tf.placeholder(tf.float32, shape=self.lambda_bc_val.shape)
        self.lambda_ic_tf = tf.placeholder(tf.float32, shape=self.lambda_ic_val.shape)

        self.loss = (self.lambda_data_tf * self.loss_data +
                     self.lambda_ic_tf * self.loss_ic +
                     self.lambda_res_tf * self.loss_res +
                     self.lambda_bc_tf * self.loss_bc)

        self.optimizer_Adam = tf.train.AdamOptimizer()
        self.train_op_Adam = self.optimizer_Adam.minimize(self.loss)

        # NTK
        self.t_data_ntk_tf = tf.placeholder(tf.float32, shape=(self.kernel_size, 1))
        self.x_data_ntk_tf = tf.placeholder(tf.float32, shape=(self.kernel_size, 1))

        self.t_res_ntk_tf = tf.placeholder(tf.float32, shape=(self.kernel_size, 1))
        self.x_res_ntk_tf = tf.placeholder(tf.float32, shape=(self.kernel_size, 1))

        self.t_bc_ntk_tf = tf.placeholder(tf.float32, shape=(self.kernel_size, 1))
        self.x_bc_ntk_tf = tf.placeholder(tf.float32, shape=(self.kernel_size, 1))

        self.t_ic_ntk_tf = tf.placeholder(tf.float32, shape=(self.kernel_size, 1))
        self.x_ic_ntk_tf = tf.placeholder(tf.float32, shape=(self.kernel_size, 1))

        u_ntk_data, v_ntk_data = self.net_uv(self.t_data_ntk_tf, self.x_data_ntk_tf)
        self.f_data_ntk = tf.concat([u_ntk_data, v_ntk_data], axis=0)

        r_u_ntk, r_v_ntk = self.net_r(self.t_res_ntk_tf, self.x_res_ntk_tf)
        self.f_res_ntk = tf.concat([r_u_ntk, r_v_ntk], axis=0)

        u_ntk_bc, v_ntk_bc = self.net_uv_x(self.t_bc_ntk_tf, self.x_bc_ntk_tf)
        self.f_bc_ntk = tf.concat([u_ntk_bc, v_ntk_bc], axis=0)

        u_ntk_ic, v_ntk_ic = self.net_uv(self.t_ic_ntk_tf, self.x_ic_ntk_tf)
        self.f_ic_ntk = tf.concat([u_ntk_ic, v_ntk_ic], axis=0)

        self.J_data = self.compute_jacobian(self.f_data_ntk)
        self.J_res = self.compute_jacobian(self.f_res_ntk)
        self.J_bc = self.compute_jacobian(self.f_bc_ntk)
        self.J_ic = self.compute_jacobian(self.f_ic_ntk)

        self.K_data = self.compute_ntk(self.J_data, self.D_data, self.J_data, self.D_data)
        self.K_res = self.compute_ntk(self.J_res, self.D_res, self.J_res, self.D_res)
        self.K_bc = self.compute_ntk(self.J_bc, self.D_bc, self.J_bc, self.D_bc)
        self.K_ic = self.compute_ntk(self.J_ic, self.D_ic, self.J_ic, self.D_ic)

        # Logger
        self.iterations = []
        self.loss_total = []
        self.loss_data_all = []
        self.loss_res_all = []
        self.loss_bc_all = []
        self.loss_ic_all = []
        self.lambda1_all = []
        self.lambda2_all = []
        self.lambda3_all = []

        self.saver = tf.train.Saver()

        # init
        init = tf.global_variables_initializer()
        self.sess.run(init)

    def xavier_init(self, size):
        in_dim, out_dim = size[0], size[1]
        xavier_stddev = np.sqrt(2 / (in_dim + out_dim))
        # xavier_stddev = 1. / np.sqrt((in_dim + out_dim) / 2.)
        return tf.Variable(tf.random_normal([in_dim, out_dim], stddev=xavier_stddev), dtype=tf.float32)

    def initialize_NN(self, layers):
        weights = []
        biases = []
        num_layers = len(layers)
        input_dim = layers[0]

        for l in range(0, num_layers - 2):
            W = self.xavier_init(size=[input_dim, layers[l + 1]])
            b = tf.Variable(tf.random_normal([1, layers[l + 1]], dtype=tf.float32), dtype=tf.float32)
            weights.append(W)
            biases.append(b)
            input_dim = layers[l + 1]

        W_last = self.xavier_init(size=[layers[-2], layers[-1]])
        b_last = tf.Variable(tf.random_normal([1, layers[-1]], dtype=tf.float32), dtype=tf.float32)
        weights.append(W_last)
        biases.append(b_last)

        return weights, biases

    def neural_net(self, H):
        t = H[:, 0:1]
        x = H[:, 1:2]

        H_t = tf.concat([tf.sin(tf.matmul(t, self.W_t)),
                         tf.cos(tf.matmul(t, self.W_t))], 1)

        H_x = tf.concat([tf.sin(tf.matmul(x, self.W_x)),
                         tf.cos(tf.matmul(x, self.W_x))], 1)

        num_layers = len(self.layers)
        for l in range(0, num_layers - 2):
            W = self.weights[l]
            b = self.biases[l]
            H_t = tf.tanh(tf.add(tf.matmul(H_t, W), b))
            H_x = tf.tanh(tf.add(tf.matmul(H_x, W), b))

        H_final = tf.multiply(H_t, H_x)

        W = self.weights[-1]
        b = self.biases[-1]
        Y = tf.add(tf.matmul(H_final, W), b)
        return Y

    def net_uv(self, t, x):
        X = tf.concat([t, x], 1)
        out = self.neural_net(X)
        u = out[:, 0:1]
        v = out[:, 1:2]
        return u, v

    def net_uv_x(self, t, x):
        u, v = self.net_uv(t, x)
        u_x = tf.gradients(u, x)[0] / self.sigma_x
        v_x = tf.gradients(v, x)[0] / self.sigma_x
        return u_x, v_x

    def net_r(self, t, x):
        u, v = self.net_uv(t, x)
        u_t = tf.gradients(u, t)[0] / self.sigma_t
        u_x = tf.gradients(u, x)[0] / self.sigma_x
        u_xx = tf.gradients(u_x, x)[0] / self.sigma_x
        v_t = tf.gradients(v, t)[0] / self.sigma_t
        v_x = tf.gradients(v, x)[0] / self.sigma_x
        v_xx = tf.gradients(v_x, x)[0] / self.sigma_x
        r_u = u_t - self.nu1 * u_xx - (self.lambda1[0] * u - v - u ** 3)
        r_v = v_t - self.nu2 * v_xx - (self.lambda2[0] * u - self.lambda3[0] * v)
        return r_u, r_v

    def compute_jacobian(self, f):
        J_list = []
        L = len(self.weights)
        for i in range(L):
            J_w = jacobian(f, self.weights[i])
            J_list.append(J_w)
        for i in range(L):
            J_b = jacobian(f, self.biases[i])
            J_list.append(J_b)
        return J_list

    def compute_ntk(self, J1_list, D1, J2_list, D2):
        Ker = tf.zeros((D1, D2), dtype=tf.float32)
        for k in range(len(J1_list)):
            J1 = tf.reshape(J1_list[k], shape=(D1, -1))
            J2 = tf.reshape(J2_list[k], shape=(D2, -1))
            Ker += tf.matmul(J1, tf.transpose(J2))
        return Ker

    def fetch_minibatch_data(self, N):
        X, Y = self.data_sampler.sample(N)
        X = (X - self.mu_X) / self.sigma_X
        return X, Y

    def fetch_minibatch_residual(self, N):
        X, _ = self.res_sampler.sample(N)
        X = (X - self.mu_X) / self.sigma_X
        return X

    def fetch_minibatch_bc(self, N):
        X, Y = self.bc_sampler.sample(N)
        X = (X - self.mu_X) / self.sigma_X
        return X, Y
    def fetch_minibatch_ic(self, N):
        X, Y = self.ic_sampler.sample(N)
        X = (X - self.mu_X) / self.sigma_X
        return X, Y

    def train(self, nIter=10000, batch_size=200, log_NTK=True, update_weights=True):
        total_start_time = time.time()
        start_time = time.time()

        # total_adam_time = 0.0
        # total_ntk_time = 0.0
        # adam_steps = 0
        # ntk_steps = 0

        for it in range(nIter):
            X_data_batch, UV_data_batch = self.fetch_minibatch_data(batch_size)
            X_ic_batch, UV_ic_batch = self.fetch_minibatch_ic(batch_size)
            X_bc_batch, _ = self.fetch_minibatch_bc(batch_size)
            X_r_batch = self.fetch_minibatch_residual(batch_size)

            tf_dict = {
                self.t_data_tf: X_data_batch[:, 0:1],
                self.x_data_tf: X_data_batch[:, 1:2],
                self.u_tf: UV_data_batch[:, 0:1],
                self.v_tf: UV_data_batch[:, 1:2],
                self.t_ic_tf: X_ic_batch[:, 0:1],
                self.x_ic_tf: X_ic_batch[:, 1:2],
                self.u_ic_tf: UV_ic_batch[:, 0:1],
                self.v_ic_tf: UV_ic_batch[:, 1:2],
                self.t_bc_tf: X_bc_batch[:, 0:1],
                self.x_bc_tf: X_bc_batch[:, 1:2],
                self.t_r_tf: X_r_batch[:, 0:1],
                self.x_r_tf: X_r_batch[:, 1:2],
                self.lambda_data_tf: self.lambda_data_val,
                self.lambda_res_tf: self.lambda_res_val,
                self.lambda_bc_tf: self.lambda_bc_val,
                self.lambda_ic_tf: self.lambda_ic_val
            }

            # step_start_time = time.time()

            self.sess.run(self.train_op_Adam, tf_dict)
            # step_elapsed = time.time() - step_start_time
            #
            # total_adam_time += step_elapsed
            # adam_steps += 1

            if it % 100 == 0:
                elapsed = time.time() - start_time
                loss_value, loss_data_value, loss_res_value, loss_bc_value, loss_ic_value = self.sess.run(
                    [self.loss, self.loss_data, self.loss_res, self.loss_bc, self.loss_ic], tf_dict)
                lambda1_value = self.sess.run(self.lambda1)
                lambda2_value = self.sess.run(self.lambda2)
                lambda3_value = self.sess.run(self.lambda3)

                current_total_iter = it
                self.iterations.append(current_total_iter)
                self.loss_total.append(loss_value)
                self.loss_data_all.append(loss_data_value)
                self.loss_res_all.append(loss_res_value)
                self.loss_bc_all.append(loss_bc_value)
                self.loss_ic_all.append(loss_ic_value)
                self.lambda1_all.append(lambda1_value[0])
                self.lambda2_all.append(lambda2_value[0])
                self.lambda3_all.append(lambda3_value[0])

                print('It: %d, Loss: %.5e, Lambda1: %.5f, Lambda2: %.5f, Lambda3: %.5f, Time: %.2f' %
                      (it, loss_value, lambda1_value, lambda2_value, lambda3_value, elapsed))

            if log_NTK and (it % 100 == 0):
                tf_ntk = {
                    self.t_data_ntk_tf: X_data_batch[:, 0:1],
                    self.x_data_ntk_tf: X_data_batch[:, 1:2],
                    self.t_res_ntk_tf: X_r_batch[:, 0:1],
                    self.x_res_ntk_tf: X_r_batch[:, 1:2],
                    self.t_bc_ntk_tf: X_bc_batch[:, 0:1],
                    self.x_bc_ntk_tf: X_bc_batch[:, 1:2],
                    self.t_ic_ntk_tf: X_ic_batch[:, 0:1],
                    self.x_ic_ntk_tf: X_ic_batch[:, 1:2]
                }

                # ntk_start_time = time.time()
                Kd, Kr, Kb, Ki = self.sess.run([self.K_data, self.K_res, self.K_bc, self.K_ic], tf_ntk)
                # ntk_elapsed = time.time() - ntk_start_time
                # total_ntk_time += ntk_elapsed
                # ntk_steps += 1

                if update_weights:
                    lam_sum = np.trace(Kd) + np.trace(Kr) + np.trace(Kb) + np.trace(Ki)
                    self.lambda_data_val = lam_sum / np.trace(Kd)
                    self.lambda_res_val = lam_sum / np.trace(Kr)
                    self.lambda_bc_val = lam_sum / np.trace(Kb)
                    self.lambda_ic_val = lam_sum / np.trace(Ki)

        total_elapsed_time = time.time() - total_start_time
        print(f"Total training time: {total_elapsed_time:.2f} seconds")

        # avg_adam_time = total_adam_time/adam_steps
        # avg_ntk_time = total_ntk_time/ntk_steps
        # overhead_ratio = avg_ntk_time/avg_adam_time
        # print(f"Average adam time: {avg_adam_time:.3f} seconds")
        # print(f"Average ntk time: {avg_ntk_time:.3f} seconds")
        # print(f"NTK Overhead Ratio: {overhead_ratio:.3f}")

    def predict(self, X_star):
        X_star = (X_star - self.mu_X) / self.sigma_X
        tf_dict = {self.t_data_tf: X_star[:, 0:1],
                   self.x_data_tf: X_star[:, 1:2],
                   self.lambda_data_tf: self.lambda_data_val,
                   self.lambda_res_tf: self.lambda_res_val,
                   self.lambda_bc_tf: self.lambda_bc_val}
        u_pred, v_pred = self.sess.run([self.u_data_pred, self.v_data_pred], tf_dict)
        return u_pred, v_pred

    def get_pred_parameters(self):
        lambda1_value = self.sess.run(self.lambda1)[0]
        lambda2_value = self.sess.run(self.lambda2)[0]
        lambda3_value = self.sess.run(self.lambda3)[0]
        return lambda1_value, lambda2_value, lambda3_value

if __name__ == '__main__':

    data = sio.loadmat('D:\\FFT-PINN\\FFT-PINN\\FHN\\FHN.mat')

    t_full = data['t'].flatten()
    x_full = data['x'].flatten()
    Exact_u_full = data['u1']
    Exact_v_full = data['u2']

    T_full, X_full = np.meshgrid(t_full, x_full)
    X_full = np.hstack((T_full.flatten()[:, None], X_full.flatten()[:, None]))
    u_full = Exact_u_full.T.flatten()[:, None]
    v_full = Exact_v_full.T.flatten()[:, None]
    UV_full = np.hstack([u_full, v_full])

    t = data['t_small'].flatten()[:, None]
    x = data['x_small'].flatten()[:, None]
    Exact_u = data['u1_small']
    Exact_v = data['u2_small']

    T, X = np.meshgrid(t, x)
    X_train = np.hstack((T.flatten()[:, None], X.flatten()[:, None]))
    u_train = Exact_u.T.flatten()[:, None]
    v_train = Exact_v.T.flatten()[:, None]
    UV_train = np.hstack([u_train, v_train])

    ics_mask = X_train[:, 0] == 0.0
    X_ics = X_train[ics_mask]
    UV_ics = UV_train[ics_mask]
    ic_sampler = DataSampler(X_ics, UV_ics, name='ICS')

    bc1_mask = X_train[:, 1] == 0.0  # x=0
    bc2_mask = X_train[:, 1] == 1.0  # x=1
    X_bc = np.vstack([X_train[bc1_mask], X_train[bc2_mask]])
    UV_bc = np.vstack([UV_train[bc1_mask], UV_train[bc2_mask]])
    bc_sampler = DataSampler(X_bc, UV_bc, name='BC')

    internal_mask = ~(ics_mask | bc1_mask | bc2_mask)
    X_internal = X_train[internal_mask]
    UV_internal = UV_train[internal_mask]
    noise_level = 0.05

    u_internal = UV_internal[:, 0:1]
    v_internal = UV_internal[:, 1:2]

    u_noisy = u_internal + noise_level * np.std(u_internal) * np.random.randn(*u_internal.shape)
    v_noisy = v_internal + noise_level * np.std(v_internal) * np.random.randn(*v_internal.shape)

    UV_noisy = np.hstack([u_noisy, v_noisy])
    data_sampler = DataSampler(X_internal, UV_noisy, name='Internal Data')

    dom_coords = np.array([[0.0, 0.0], [20.0, 1.0]])

    res_sampler = LHSSampler(2, dom_coords, name='Residual')

    nu1, nu2 = 0.001, 0.004
    lambda1_true = 1.0
    lambda2_true = 0.4
    lambda3_true = 0.2

    layers = [36, 36, 36, 36, 2]
    kernel_size = 32

    model = FHN_PINN_mFF_NTK(data_sampler, res_sampler, bc_sampler,
                             ic_sampler,
                             layers, nu1, nu2, kernel_size)

    model.train(nIter=40000, batch_size=kernel_size, log_NTK=True, update_weights=True)

    lambda1_pred, lambda2_pred, lambda3_pred = model.get_pred_parameters()

    abs_error_lambda1 = np.abs(lambda1_pred - lambda1_true)
    abs_error_lambda2 = np.abs(lambda2_pred - lambda2_true)
    abs_error_lambda3 = np.abs(lambda3_pred - lambda3_true)
    rel_error_lambda1 = (abs_error_lambda1 / np.abs(lambda1_true)) * 100
    rel_error_lambda2 = (abs_error_lambda2 / np.abs(lambda2_true)) * 100
    rel_error_lambda3 = (abs_error_lambda3 / np.abs(lambda3_true)) * 100

    print(f"True lambda1: {lambda1_true}, Identified: {lambda1_pred:.5f}")
    print(f"Absolute Error: {abs_error_lambda1:.5f}")
    print(f"Relative Error: {rel_error_lambda1:.5f}%")

    print(f"True lambda2: {lambda2_true}, Identified: {lambda2_pred:.5f}")
    print(f"Absolute Error: {abs_error_lambda2:.5f}")
    print(f"Relative Error: {rel_error_lambda2:.5f}%")

    print(f"True lambda3: {lambda3_true}, Identified: {lambda3_pred:.5f}")
    print(f"Absolute Error: {abs_error_lambda3:.5f}")
    print(f"Relative Error: {rel_error_lambda3:.5f}%")

########################################################### Plot #################################################

    # plt.rcParams['font.family'] = 'serif'
    # plt.rcParams['font.serif'] = ['Times New Roman']
    # plt.rcParams['font.size'] = 15
    # plt.rcParams['axes.titlesize'] = 18
    # plt.rcParams['axes.labelsize'] = 15
    # plt.rcParams['legend.fontsize'] = 13
    # # ---------- 1. Loss ----------
    # plt.figure(figsize=(10, 6))
    # plt.plot(model.iterations, model.loss_total, 'b-', linewidth=2, label='Total Loss')
    # plt.plot(model.iterations, model.loss_res_all, 'r--', linewidth=2, label='Residual Loss')
    # plt.plot(model.iterations, model.loss_bc_all, 'g--', linewidth=2, label='BC Loss')
    # plt.plot(model.iterations, model.loss_ic_all, 'y--', linewidth=2, label='IC Loss')
    # plt.plot(model.iterations, model.loss_data_all, 'm--', linewidth=2, label='Data Loss')
    #
    # plt.xlabel('Iterations')
    # plt.ylabel('Loss')
    # plt.yscale('log')
    # plt.legend()
    # plt.grid(True, alpha=0.3)
    # plt.title('Training Loss History')
    # plt.savefig('fhn_loss_history.png', dpi=300, bbox_inches='tight')
    # plt.close()
    # # plt.tight_layout()
    # # plt.show()
    #
    # # ---------- 2. Parameters ----------
    # plt.figure(figsize=(10, 6))
    #
    # plt.plot(model.iterations, model.lambda1_all, 'r-', linewidth=2, label='Estimated $\lambda_1$')
    # plt.plot(model.iterations, model.lambda2_all, 'b-', linewidth=2, label='Estimated $\lambda_2$')
    # plt.plot(model.iterations, model.lambda3_all, 'g-', linewidth=2, label='Estimated $\lambda_3$')
    #
    # plt.axhline(y=lambda1_true, color='r', linestyle=':', linewidth=2, alpha=0.7,
    #             label=f'True $\lambda_1$ = {lambda1_true}')
    # plt.axhline(y=lambda2_true, color='b', linestyle=':', linewidth=2, alpha=0.7,
    #             label=f'True $\lambda_2$ = {lambda2_true}')
    # plt.axhline(y=lambda3_true, color='g', linestyle=':', linewidth=2, alpha=0.7,
    #             label=f'True $\lambda_3$ = {lambda3_true}')
    #
    # plt.xlabel('Iterations')
    # plt.ylabel('Parameter Values')
    # plt.legend(loc='center right',  bbox_to_anchor=(0.95, 0.7))
    # plt.grid(True, alpha=0.3)
    # plt.title('Parameter Convergence')
    # plt.savefig('fhn_param_convergence.png', dpi=300, bbox_inches='tight')
    # plt.close()
    # plt.tight_layout()
    # plt.show()
    #
    # # # ---------- 3. Ture & Pred ----------
    u_pred_full, v_pred_full = model.predict(X_full)
    err_u_full = np.linalg.norm(u_full - u_pred_full, 2) / np.linalg.norm(u_full, 2)
    err_v_full = np.linalg.norm(v_full - v_pred_full, 2) / np.linalg.norm(v_full, 2)
    print(f"Relative L2 error (full field) - u: {err_u_full:.5e}, v: {err_v_full:.5e}")
    #
    # U_exact = u_full.reshape(Exact_u_full.T.shape)
    # V_exact = v_full.reshape(Exact_v_full.T.shape)
    # U_pred_plot = u_pred_full.reshape(Exact_u_full.T.shape)
    # V_pred_plot = v_pred_full.reshape(Exact_v_full.T.shape)
    #
    # T_grid, X_grid = np.meshgrid(t_full, x_full)
    #
    # # u(x,t)
    # fig = plt.figure(figsize=(18, 5))
    #
    # plt.subplot(1, 3, 1)
    # plt.pcolormesh(T_grid, X_grid, U_exact, cmap='jet', shading='auto')
    # plt.colorbar()
    # plt.xlabel('t')
    # plt.ylabel('x')
    # plt.title('Exact Solution u(x,t)')
    #
    # plt.subplot(1, 3, 2)
    # plt.pcolormesh(T_grid, X_grid, U_pred_plot, cmap='jet', shading='auto')
    # plt.colorbar()
    # plt.xlabel('t')
    # plt.ylabel('x')
    # plt.title('Predicted Solution u(x,t)')
    #
    # plt.subplot(1, 3, 3)
    # plt.pcolormesh(T_grid, X_grid, np.abs(U_exact - U_pred_plot), cmap='jet', shading='auto')
    # plt.colorbar()
    # plt.xlabel('t')
    # plt.ylabel('x')
    # plt.title('Absolute Error')
    # plt.savefig('fhn_solution_u.png', dpi=300, bbox_inches='tight')
    # plt.close()
    #
    # # plt.tight_layout()
    # # plt.show()
    #
    # # v(x,t)
    # fig = plt.figure(figsize=(18, 5))
    #
    # plt.subplot(1, 3, 1)
    # plt.pcolormesh(T_grid, X_grid, V_exact, cmap='jet', shading='auto')
    # plt.colorbar()
    # plt.xlabel('t')
    # plt.ylabel('x')
    # plt.title('Exact Solution v(x,t)')
    #
    # plt.subplot(1, 3, 2)
    # plt.pcolormesh(T_grid, X_grid, V_pred_plot, cmap='jet', shading='auto')
    # plt.colorbar()
    # plt.xlabel('t')
    # plt.ylabel('x')
    # plt.title('Predicted Solution v(x,t)')
    #
    # plt.subplot(1, 3, 3)
    # plt.pcolormesh(T_grid, X_grid, np.abs(V_exact - V_pred_plot), cmap='jet', shading='auto')
    # plt.colorbar()
    # plt.xlabel('t')
    # plt.ylabel('x')
    # plt.title('Absolute Error')
    # plt.savefig('fhn_solution_v.png', dpi=300, bbox_inches='tight')
    # plt.close()
    #
    # # plt.tight_layout()
    # # plt.show()
